
fun main(){

    println("he is great")


}