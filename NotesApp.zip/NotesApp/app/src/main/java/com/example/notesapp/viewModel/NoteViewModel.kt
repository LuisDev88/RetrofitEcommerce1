package com.example.notesapp.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.notesapp.database.NoteDao
import com.example.notesapp.database.NoteDatabase
import com.example.notesapp.database.NoteRepository
import com.example.notesapp.model.Note
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {

    var repository: NoteRepository
    val readAllNote:LiveData<List<Note>>


    init {
        var dao=NoteDatabase.getDataBase(application).dao()

        repository=NoteRepository(dao)

        readAllNote= repository.getAllNote()
    }



    fun insertNote(note: Note) = viewModelScope.launch(Dispatchers.IO) {

            repository.insertNote(note)
        }




    fun deleteNote(note: Note) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNote(note)

        }


    fun updateNote(note: Note) =
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateNote(note)

        }


    fun deleteAllNote() = viewModelScope.launch(Dispatchers.IO) {

        repository.deleteAllNote()
    }







    fun searchNote(query: String?) = repository.searchNote(query)





}