package com.example.notesapp.fragments

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.notesapp.R
import com.example.notesapp.databinding.FragmentEditNoteBinding
import com.example.notesapp.model.Note
import com.example.notesapp.viewModel.NoteViewModel
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date


class EditNoteFragment : Fragment() {

private lateinit var binding:FragmentEditNoteBinding
private lateinit var myViewModel: NoteViewModel

private lateinit var iconDelete:ImageView
private lateinit var iconShare:ImageView

 private val args by navArgs<EditNoteFragmentArgs>()

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding=DataBindingUtil.inflate(inflater,R.layout.fragment_edit_note, container, false)

   myViewModel=ViewModelProvider(this).get(NoteViewModel::class.java)

        iconDelete=binding.root.findViewById(R.id.editNote_delete)
        iconShare=binding.root.findViewById(R.id.share_icon)


   binding.editNoteTitle.setText(args.currentNoteItem.noteTitle)
    binding.editNoteDesc.setText(args.currentNoteItem.noteDesc)


        binding.editNoteFab.setOnClickListener {

            editNote()

        }


        iconDelete.setOnClickListener {

            deleteNote()


        }

iconShare.setOnClickListener {
    shareNote()

}



    return binding.root
    }



    private fun deleteNote(){

        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("Yes"){_,_ ->

            myViewModel.deleteNote(args.currentNoteItem)

            Toast.makeText(context, "Note deleted successfully", Toast.LENGTH_SHORT).show()

            findNavController().navigate(EditNoteFragmentDirections.actionEditNoteFragmentToHomeFragment())


        }
        builder.setNegativeButton("No"){_,_ ->}

        builder.setTitle("Delete note?")
        builder.setMessage("Are you sure you want to delete this note?")
        builder.create().show()

    }


    @RequiresApi(Build.VERSION_CODES.O)
    private fun editNote(){

        val EditTitle=binding.editNoteTitle.text.toString()
        val EditDesc=binding.editNoteDesc.text.toString()
        val dateUpdated=SimpleDateFormat("EEE, dd MMM yy HH:mm a" )

        if(EditTitle.isNotEmpty() && EditDesc.isNotEmpty()){

            val note=Note(args.currentNoteItem.id, EditTitle, EditDesc, dateUpdated.format(Date()))
            myViewModel.updateNote(note)

            Toast.makeText(context, "Note updated successfully", Toast.LENGTH_SHORT).show()

            findNavController().navigate(EditNoteFragmentDirections.actionEditNoteFragmentToHomeFragment())


        }
    }


    private fun shareNote(){

            val intent=Intent(Intent.ACTION_SEND)
            intent.setType("text/plain")
            intent.putExtra(Intent.EXTRA_SUBJECT, args.currentNoteItem.noteTitle)
            intent.putExtra(Intent.EXTRA_TEXT, args.currentNoteItem.noteDesc)

            startActivity(intent)




    }

}