package com.example.notesapp.fragments

import android.graphics.Color
import android.media.Image
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.SearchView
//import androidx.appcompat.widget.SearchView

import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.notesapp.R
import com.example.notesapp.adapter.NoteAdapter
import com.example.notesapp.databinding.FragmentHomeBinding
import com.example.notesapp.model.Note
import com.example.notesapp.viewModel.NoteViewModel


class HomeFragment : Fragment(), SearchView.OnQueryTextListener {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var myViewModel: NoteViewModel
    private lateinit var myAdapter: NoteAdapter
    private lateinit var searchIcon: SearchView
    private lateinit var homeDeleteIcon: ImageView



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)

        //SETTING UP VIEWMODEL
        myViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)


        //HOME VIEWS ITEM
        searchIcon = binding.include.findViewById(R.id.icon_search)
        homeDeleteIcon = binding.include.findViewById(R.id.home_delete)

        //SEARCH VIEW ONCLICK-LISTENER
        searchIcon.setOnQueryTextListener(this)
        searchIcon.isSubmitButtonEnabled = false


        //SETTING UP ADAPTER AND RECYCLERVIEW
        myAdapter = NoteAdapter()
        binding.recyclerView.adapter = myAdapter
        binding.recyclerView.layoutManager =
            StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        binding.recyclerView.setHasFixedSize(true)


        // FUNCTION THAT READS THE NOTES FROM ROOM DATABASE AND DISPLAY THE NOTE ON RECYCLERVIEW
        displayNote()


        binding.AddNoteFab.setOnClickListener {

            val direction = HomeFragmentDirections.actionHomeFragmentToAddNoteFragment()

            it.findNavController().navigate(direction)

        }


        // DELETING ALL NOTES
        homeDeleteIcon.setOnClickListener {


            if (binding.recyclerView.visibility == View.VISIBLE && binding.emptyNoteView.visibility == View.GONE) {

                deleteAllNote()
            } else {

                binding.emptyNoteView.visibility == View.VISIBLE && binding.recyclerView.visibility == View.GONE

                Toast.makeText(context, "No notes to delete", Toast.LENGTH_SHORT).show()
            }


        }



        return binding.root
    }


    private fun updateUI(note: List<Note>?) {

        if (note != null) {

            if (note.isNotEmpty()) {

                binding.emptyNoteView.visibility = View.GONE
                binding.recyclerView.visibility = View.VISIBLE


            } else {

                binding.emptyNoteView.visibility = View.VISIBLE
                binding.recyclerView.visibility = View.GONE

            }

        }


    }


    private fun displayNote() {

        myViewModel.readAllNote.observe(viewLifecycleOwner) { note ->

            myAdapter.differ.submitList(note)

            updateUI(note)
        }

    }


    private fun deleteAllNote() {


        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("Yes") { _, _ ->

            myViewModel.deleteAllNote()

            Toast.makeText(context, "All Notes deleted successfully", Toast.LENGTH_SHORT).show()

        }
        builder.setNegativeButton("No") { _, _ -> }

        builder.setTitle("Delete All Notes?")
        builder.setMessage("Are you sure you want to delete all notes?")
        builder.create().show()


    }


    private fun searchDatabase(query: String?) {

        val searchQuery = "%$query%"

        myViewModel.searchNote(searchQuery).observe(this) { list ->

            myAdapter.differ.submitList(list)
        }

    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        return false
    }

    override fun onQueryTextChange(query: String?): Boolean {
        if (query != null) {

            searchDatabase(query)
        }
        return true
    }




}






