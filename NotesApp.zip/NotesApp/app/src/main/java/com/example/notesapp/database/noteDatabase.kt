package com.example.notesapp.database

import android.app.Application
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.notesapp.model.Note

@Database(entities = [Note::class], version = 2, exportSchema = false)
abstract class NoteDatabase : RoomDatabase() {

    abstract fun dao(): NoteDao

    companion object {
        @Volatile

        var INSTANCE: NoteDatabase? = null


        val  migration1To2:Migration=object :Migration(1,2){
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE NoteTable ADD COLUMN date TEXT DEFAULT '' ")
            }


        }


        fun getDataBase(context: Application): NoteDatabase {


            synchronized(this) {

                var instance = INSTANCE

                if (instance == null) {

                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        NoteDatabase::class.java,
                        "NoteTable"
                    ) .addMigrations(migration1To2)
                        .build()

                }

                return instance


            }


        }

    }


}