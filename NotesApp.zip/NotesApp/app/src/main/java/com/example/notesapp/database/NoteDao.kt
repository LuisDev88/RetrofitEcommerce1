package com.example.notesapp.database
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.notesapp.model.Note


@Dao
interface NoteDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertNote(note:Note)

    @Delete
    suspend fun deleteNote(note:Note)

    @Update
    suspend fun updateNote(note:Note)

    @Query("select * from notetable order by id DESC")
    fun getAllNote():LiveData<List<Note>>

    @Query("select * from notetable where noteTitle like:query or noteDesc like:query ")
    fun searchNote(query: String?):LiveData<List<Note>>

    @Query("delete from notetable")
    suspend fun deleteAllNote()


}