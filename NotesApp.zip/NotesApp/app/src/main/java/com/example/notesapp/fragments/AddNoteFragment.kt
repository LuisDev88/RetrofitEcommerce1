package com.example.notesapp.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.notesapp.R
import com.example.notesapp.databinding.FragmentAddNoteBinding
import com.example.notesapp.model.Note
import com.example.notesapp.viewModel.NoteViewModel
import java.text.SimpleDateFormat
import java.util.Date


class AddNoteFragment : Fragment() {
    private lateinit var binding: FragmentAddNoteBinding
    private lateinit var myViewModel: NoteViewModel
    private lateinit var doneIcon: ImageView
    private lateinit var backArrow: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_add_note, container, false)

        myViewModel = ViewModelProvider(this).get(NoteViewModel::class.java)

        doneIcon = binding.root.findViewById(R.id.icon_done)

        backArrow = binding.root.findViewById(R.id.icon_back)



        doneIcon.setOnClickListener {

            InsertNote()

        }

        backArrow.setOnClickListener {
            findNavController().navigate(AddNoteFragmentDirections.actionAddNoteFragmentToHomeFragment())

            Toast.makeText(context, "Note not added", Toast.LENGTH_SHORT).show()
        }


        return binding.root
    }


   fun InsertNote() {

        val edtTitleAdd = binding.AddNoteTitle.text.toString()
        val edtDescAdd = binding.AddNoteDesc.text.toString()
       val dateCreated = SimpleDateFormat("EEE, dd MMM yy HH:mm a" )

        if (edtTitleAdd.isNotEmpty() && edtDescAdd.isNotEmpty()) {

            val note = Note(0, edtTitleAdd, edtDescAdd, dateCreated.format(Date()))

            myViewModel.insertNote(note)



            Toast.makeText(context, "Note successfully added", Toast.LENGTH_LONG).show()

            findNavController().navigate(AddNoteFragmentDirections.actionAddNoteFragmentToHomeFragment())

        } else {

                Toast.makeText(context, "fill out the fields", Toast.LENGTH_SHORT).show()

        }


    }


}