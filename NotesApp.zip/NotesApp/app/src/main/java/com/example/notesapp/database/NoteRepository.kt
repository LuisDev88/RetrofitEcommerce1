package com.example.notesapp.database

import androidx.lifecycle.LiveData
import com.example.notesapp.model.Note

class NoteRepository(private val dao: NoteDao) {




    suspend fun insertNote(note:Note) = dao.insertNote(note)



    suspend fun deleteNote(note: Note) = dao.deleteNote(note)


    suspend fun updateNote(note: Note) = dao.updateNote(note)


    suspend fun deleteAllNote() = dao.deleteAllNote()


    fun searchNote(query: String?) = dao.searchNote(query)


    fun getAllNote():LiveData<List<Note>> = dao.getAllNote()

}