package com.example.mypracticeapplication.ViewModel

import com.example.mypracticeapplication.ProductModel.Products
import com.example.mypracticeapplication.Retrofit.PostRetrofit
import retrofit2.Response

class Repository {

    suspend fun getPost():List<Products>{
       return PostRetrofit.api.getPost()

    }


}