package com.example.mypracticeapplication.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mypracticeapplication.ProductModel.Products
import kotlinx.coroutines.launch

class viewModel(private val repository: Repository):ViewModel() {

    val ProductList: MutableLiveData<List<Products>> = MutableLiveData()




    init {
        fetchPost()
    }

    private fun fetchPost(){

        viewModelScope.launch {

            val product=repository.getPost()

           ProductList.postValue(product)

        }


    }






}