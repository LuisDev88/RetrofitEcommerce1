package com.example.mypracticeapplication.productAdapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mypracticeapplication.ProductModel.Products
import com.example.mypracticeapplication.R

class ItemAdapter():RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {







    inner class ItemViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){

        val title= itemView.findViewById<TextView>(R.id.title)
        val price = itemView.findViewById<TextView>(R.id.price)
        val desc= itemView.findViewById<TextView>(R.id.desc)
        val category = itemView.findViewById<TextView>(R.id.category)
        val image= itemView.findViewById<ImageView>(R.id.imageView)



    }





    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val item= LayoutInflater.from(parent.context).inflate(R.layout.product_item, parent, false)
        return ItemViewHolder(item)
    }


    var callback=object :DiffUtil.ItemCallback<Products>(){
        override fun areItemsTheSame(
            oldItem: Products,
            newItem: Products
        ): Boolean {
          return  oldItem.id==newItem.id
        }

        override fun areContentsTheSame(
            oldItem: Products,
            newItem: Products
        ): Boolean {
         return oldItem==newItem
        }


    }

    val differ = AsyncListDiffer(this, callback)


    override fun getItemCount(): Int {
        return differ.currentList.size
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {

        val currentProduct= differ.currentList[position]


        holder.itemView.apply {

            holder.title.text = currentProduct.title
            holder.price.text = "$${currentProduct.price.toString()}"
            holder.category.text = currentProduct.category
            holder.desc.text = currentProduct.description
            Glide.with(context).load(currentProduct.image).into(holder.image)



        }








    }





}