package com.example.mypracticeapplication.Retrofit

import com.example.mypracticeapplication.ProductModel.Products
import retrofit2.Response
import retrofit2.http.GET

interface PostAPI {


    @GET("products/")
    suspend fun getPost():List<Products>



}