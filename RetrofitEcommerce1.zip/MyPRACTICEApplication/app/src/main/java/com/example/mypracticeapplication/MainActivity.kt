package com.example.mypracticeapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mypracticeapplication.ViewModel.Repository
import com.example.mypracticeapplication.ViewModel.viewModel
import com.example.mypracticeapplication.ViewModel.viewModelFactory
import com.example.mypracticeapplication.databinding.ActivityMainBinding
import com.example.mypracticeapplication.productAdapter.ItemAdapter


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    lateinit var myViewModel: viewModel
    lateinit var repository: Repository
    lateinit var factory: viewModelFactory
    lateinit var myAdapter: ItemAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        repository= Repository()

        factory= viewModelFactory(repository)

        myViewModel= ViewModelProvider(this, factory).get(viewModel::class.java)


        // RECYCLERVIEW

        setUpRecyclerView()

        
   myViewModel.ProductList.observe(this, Observer { response ->

     myAdapter.differ.submitList(response)


   })






    }


    private fun setUpRecyclerView(){

        myAdapter = ItemAdapter()

        binding.productRecyclerView.apply {

            adapter=myAdapter

            layoutManager= LinearLayoutManager(context)

            setHasFixedSize(true)



        }



    }



}




