package com.example.mypracticeapplication.ProductModel

data class Products(
    val id: Int,
    val title: String,
    val description: String,
    val image:String,
    val price: Double,
    val category: String,

)