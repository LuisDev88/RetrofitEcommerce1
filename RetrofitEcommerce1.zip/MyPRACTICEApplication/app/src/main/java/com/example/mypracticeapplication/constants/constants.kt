package com.example.mypracticeapplication.constants

class constants {

    companion object{
        const val BASE_URL = "https://fakestoreapi.com/"

    }

}